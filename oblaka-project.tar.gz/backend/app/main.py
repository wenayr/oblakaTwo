from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import openai
import google.generativeai as genai
import os
from typing import Optional, List
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Облака AI API",
    description="AI-сервис с поддержкой OpenAI и Gemini",
    version="1.0.0"
)

# Настройка CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Настройка API ключей
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_API_KEY2 = os.getenv("OPENAI_API_KEY2")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GEMINI_API_KEY2 = os.getenv("GEMINI_API_KEY2")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-flash-latest")

# Инициализация OpenAI
if OPENAI_API_KEY:
    openai.api_key = OPENAI_API_KEY
    logger.info("OpenAI API инициализирован")

# Инициализация Gemini
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)
    logger.info("Gemini API инициализирован")

# Модели данных
class ChatRequest(BaseModel):
    message: str
    model: str = "openai"  # "openai" или "gemini"
    max_tokens: Optional[int] = 1000
    temperature: Optional[float] = 0.7

class ChatResponse(BaseModel):
    response: str
    model_used: str
    tokens_used: Optional[int] = None

class HealthResponse(BaseModel):
    status: str
    openai_available: bool
    gemini_available: bool

# Основные endpoints
@app.get("/")
async def root():
    return {
        "message": "Добро пожаловать в Облака AI!",
        "version": "1.0.0",
        "description": "AI-сервис с поддержкой OpenAI и Gemini"
    }

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Проверка состояния сервиса и доступности AI моделей"""
    openai_available = bool(OPENAI_API_KEY)
    gemini_available = bool(GEMINI_API_KEY)
    
    return HealthResponse(
        status="ok",
        openai_available=openai_available,
        gemini_available=gemini_available
    )

@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """Основной endpoint для общения с AI"""
    try:
        if request.model == "openai":
            return await chat_with_openai(request)
        elif request.model == "gemini":
            return await chat_with_gemini(request)
        else:
            raise HTTPException(status_code=400, detail="Неподдерживаемая модель")
    except Exception as e:
        logger.error(f"Ошибка в chat endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Ошибка обработки запроса: {str(e)}")

async def chat_with_openai(request: ChatRequest) -> ChatResponse:
    """Обработка запроса через OpenAI"""
    if not OPENAI_API_KEY:
        raise HTTPException(status_code=503, detail="OpenAI API недоступен")
    
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "Ты полезный AI-ассистент. Отвечай на русском языке."},
                {"role": "user", "content": request.message}
            ],
            max_tokens=request.max_tokens,
            temperature=request.temperature
        )
        
        return ChatResponse(
            response=response.choices[0].message.content,
            model_used="OpenAI GPT-3.5",
            tokens_used=response.usage.total_tokens
        )
    except Exception as e:
        logger.error(f"Ошибка OpenAI API: {str(e)}")
        # Попробуем второй ключ
        if OPENAI_API_KEY2:
            try:
                openai.api_key = OPENAI_API_KEY2
                response = openai.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": "Ты полезный AI-ассистент. Отвечай на русском языке."},
                        {"role": "user", "content": request.message}
                    ],
                    max_tokens=request.max_tokens,
                    temperature=request.temperature
                )
                return ChatResponse(
                    response=response.choices[0].message.content,
                    model_used="OpenAI GPT-3.5 (backup)",
                    tokens_used=response.usage.total_tokens
                )
            except Exception as e2:
                logger.error(f"Ошибка backup OpenAI API: {str(e2)}")
        
        raise HTTPException(status_code=503, detail=f"Ошибка OpenAI API: {str(e)}")

async def chat_with_gemini(request: ChatRequest) -> ChatResponse:
    """Обработка запроса через Gemini"""
    if not GEMINI_API_KEY:
        raise HTTPException(status_code=503, detail="Gemini API недоступен")
    
    try:
        model = genai.GenerativeModel(GEMINI_MODEL)
        response = model.generate_content(
            request.message,
            generation_config=genai.types.GenerationConfig(
                max_output_tokens=request.max_tokens,
                temperature=request.temperature,
            )
        )
        
        return ChatResponse(
            response=response.text,
            model_used=f"Google {GEMINI_MODEL}",
            tokens_used=None  # Gemini не всегда предоставляет информацию о токенах
        )
    except Exception as e:
        logger.error(f"Ошибка Gemini API: {str(e)}")
        # Попробуем второй ключ
        if GEMINI_API_KEY2:
            try:
                genai.configure(api_key=GEMINI_API_KEY2)
                model = genai.GenerativeModel(GEMINI_MODEL)
                response = model.generate_content(
                    request.message,
                    generation_config=genai.types.GenerationConfig(
                        max_output_tokens=request.max_tokens,
                        temperature=request.temperature,
                    )
                )
                return ChatResponse(
                    response=response.text,
                    model_used=f"Google {GEMINI_MODEL} (backup)",
                    tokens_used=None
                )
            except Exception as e2:
                logger.error(f"Ошибка backup Gemini API: {str(e2)}")
        
        raise HTTPException(status_code=503, detail=f"Ошибка Gemini API: {str(e)}")

@app.get("/models")
async def get_available_models():
    """Получить список доступных моделей"""
    models = []
    
    if OPENAI_API_KEY:
        models.append({
            "id": "openai",
            "name": "OpenAI GPT-3.5",
            "description": "Мощная языковая модель от OpenAI",
            "available": True
        })
    
    if GEMINI_API_KEY:
        models.append({
            "id": "gemini",
            "name": f"Google {GEMINI_MODEL}",
            "description": "Современная модель от Google",
            "available": True
        })
    
    return {"models": models}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)


const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Основной маршрут
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// API маршруты для проксирования к backend
app.get('/api/health', async (req, res) => {
    try {
        const axios = require('axios');
        const response = await axios.get('http://localhost:8001/health');
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: 'Backend недоступен' });
    }
});

app.get('/api/models', async (req, res) => {
    try {
        const axios = require('axios');
        const response = await axios.get('http://localhost:8001/models');
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: 'Backend недоступен' });
    }
});

app.post('/api/chat', async (req, res) => {
    try {
        const axios = require('axios');
        const response = await axios.post('http://localhost:8001/chat', req.body);
        res.json(response.data);
    } catch (error) {
        if (error.response) {
            res.status(error.response.status).json(error.response.data);
        } else {
            res.status(500).json({ error: 'Backend недоступен' });
        }
    }
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`Frontend сервер запущен на порту ${PORT}`);
});

